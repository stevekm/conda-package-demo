#!/bin/bash

echo "This is the custom package script!"
