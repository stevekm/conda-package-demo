#!/bin/bash

printf "This is the custom package script!\n"
